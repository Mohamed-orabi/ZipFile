﻿using System;
using System.IO.Compression;
using System.IO;
using static System.Net.Mime.MediaTypeNames;
using System.Linq;
using System.Collections.Generic;

namespace TestingZip
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var images = Directory.GetFiles(@"F:\TestingZip").ToList();

            var ls = images.partition(50);
            int count = 1;

            foreach (var item in ls)
            {
                CreateZipFile(item, count);
                count++;
            }

        }

        static void CreateZipFile(List<string> names,int num)
        {
            if (File.Exists($@"F:\TestingZip\archive{num}.zip"))
                File.Delete($@"F:\TestingZip\archive{num}.zip");

            using var archive =
                ZipFile
                .Open($@"F:\TestingZip\archive{num}.zip", ZipArchiveMode.Create);

            foreach (var image in names)
            {
                if (image == $@"F:\TestingZip\archive{num}.zip")
                    continue;

                var entry =
                    archive.CreateEntryFromFile(
                        image,
                        Path.GetFileName(image),
                        CompressionLevel.Fastest
                    );

                Console.WriteLine($"{entry.FullName} was compressed.");
            }
        }

    }
}
